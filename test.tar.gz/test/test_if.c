
/* type compose */
 
struct st { 
 int u,k;
 char** s;
} ;


void main () 
{
 // declaration
 int i,j; 
 int v;
 char* c;
 char k;
 struct st test;
 // type complex
 for(test;test;){;;;;;}

 
 return ;
}
