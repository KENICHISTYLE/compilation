/*  Fichier de test */


void main () 
{
 // declaration
 int i,j; 
 char i;
 
 return ;
}

