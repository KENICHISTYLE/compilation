struct stl { 
 struct u k;
 char** s;
} ;
void f(void x )
{
}

void main () 
{
 // declaration
 int i,j; 
 void x;
 int v;
 char* c;
 char k;
 //struct st test;
 // type complex


return ;
}
