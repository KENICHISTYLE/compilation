
struct c {
int  c;
};

struct c fun(char k){
	int  x;
 return x;	
}


void main () 
{
 
 return ;
}

