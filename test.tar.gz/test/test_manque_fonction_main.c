/*  Fichier de test */



void xixi () 
{
 // declaration
 int i,j; 
 int v;
 char* c;
 char k;
 // type complex
 char s[2];
 int tab [1] [2];
 
 // qulque operateur
 i = 0;
 c = &k;
 i = i++;
 j = i--;
 v = i * j;
 
 /* test du if et if else*/
 if ( v = i) k = 't';
 if (1) ;else i--;
 //test des boucles
 for (i=0;i<2;i++){};
 while (i == 12);
 // test du retour de fonction
 return ;
}

