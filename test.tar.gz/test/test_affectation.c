
/*  Fichier de test */


/* type compose */
 
struct st { 
 int u,k;
 char** s;
} ;


void main () 
{
 // declaration
	struct st x;
 
 // qulque operateur
 x++;
 // appel de fonction
 
 return ;
}

